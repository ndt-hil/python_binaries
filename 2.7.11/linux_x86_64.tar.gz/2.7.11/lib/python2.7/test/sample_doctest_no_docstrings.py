# This is a sample module used for testing doctest.
#
# This module is for testing how doctest handles a module with no
# docstrings.


class Foo(object):

    # A class with no docstring.

    def __init__(self):
        pass
